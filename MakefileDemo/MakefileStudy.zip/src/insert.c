#include "../include/insert.h"
#include <stdio.h>

void insert(){
   printf("read then insert!\n");
}
