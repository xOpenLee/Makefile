/*
 * array.c
 *
 *  Created on: Jan 6, 2012
 *      Author: sanglei
 */

#include <stdio.h>
#include "../../include/array.h"

void create_array(){
	printf("create array\n");
}
