/*
 * stack.c
 *
 *  Created on: Jan 6, 2012
 *      Author: sanglei
 */

#include <stdio.h>
#include "../../include/stack.h"
#include "../../include/array.h"

void create_stack(){
	printf("call array.c\n");
	create_array();
	printf("you are in stack.c now!\n");
}
