#include "../include/file.h"
#include <stdio.h>

void read(){
  printf("read file!\n");
}
