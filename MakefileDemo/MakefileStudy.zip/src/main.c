#include <stdio.h>
#include "../include/insert.h"
#include "../include/stack.h"

int main(){
  create_stack();
  insert();
  printf("main function\n");
  return 0;
}
