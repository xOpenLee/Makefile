/*
 * array.h
 *
 *  Created on: Jan 6, 2012
 *      Author: sanglei
 */

#ifndef ARRAY_H_
#define ARRAY_H_

void create_array();

#endif /* ARRAY_H_ */
