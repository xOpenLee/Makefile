#ifndef _INSERT_H
#define _INSERT_H

#include "file.h"

void insert();

#endif
