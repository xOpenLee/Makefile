/*
 * stack.h
 *
 *  Created on: Jan 6, 2012
 *      Author: sanglei
 */

#ifndef STACK_H_
#define STACK_H_

void create_stack();

#endif /* STACK_H_ */
